# Critical Analysis — `fourier_series.py` (Fourier Series Scene)

The scene was generated, run with `manim -ql fourier_series.py FourierSeries`,
and inspected frame-by-frame. Below are five concrete shortcomings found in
the actual rendered output (see `fourier_frame_mid.png` and
`fourier_frame_final.png`), not hypothetical ones.

## 1. No numeric axis scale
**Issue:** `Axes` is created with `axis_config={"include_tip": False}` and
tick marks are visible, but `axes.add_coordinates()` (or any numeric
labeling) is never called. The x-axis spans `0` to `4π`, but the viewer sees
unlabeled tick marks with no numbers and no `π`/`2π`/`3π`/`4π` markers; the
y-axis likewise shows ticks with no `-1`, `0`, `1` values.
**Why it matters:** Without a labeled scale, a viewer cannot read the period
of the square wave, the amplitude of any harmonic, or verify the `4/π`
scaling factor — the plot becomes a picture of "some wiggly lines" rather
than a quantitative demonstration.
**Fix:** Call `axes.add_coordinates()` after creating the axes, or
explicitly add `MathTex`/`Text`-based tick labels at multiples of `PI` on the
x-axis and at `-1, 0, 1` on the y-axis.

## 2. The most important curve has no legend entry
**Issue:** Every individual harmonic gets a small `n=k` label at the top of
the frame, but the cumulative **partial sum** curve (drawn in `RED`) — the
actual answer to "how does the square wave get built up?" — is never
labeled anywhere in the scene.
**Why it matters:** The partial sum is the entire point of a Fourier-series
demo. Leaving it unlabeled means a first-time viewer has to *guess* which of
the six curves on screen represents the cumulative approximation versus an
individual term.
**Fix:** Add a persistent legend entry, e.g.
`Text("partial sum", color=RED).next_to(axes, UP, aligned_edge=LEFT)`,
created once before the harmonic loop and kept on screen throughout.

## 3. Overlapping bottom-of-frame text labels
**Issue:** `square_label` ("target square wave") is written below the axes
early in the scene and never removed. Later, `final_label` ("Sum of 5
harmonics approximates the square wave") is written to the *same* position
(`next_to(axes, DOWN)`). By the final frame both strings occupy the same
pixels and are illegible (confirmed in the rendered output).
**Why it matters:** Exactly like the squares-collision bug in the Pythagoras
scene, this is the kind of error that's invisible from reading the code but
obvious — and embarrassing — the moment the video is actually played.
**Fix:** `self.play(FadeOut(square_label))` before writing `final_label`, or
place the two labels in different, non-overlapping regions of the frame from
the start.

## 4. Hardcoded `y_range` that isn't validated against Gibbs overshoot
**Issue:** `y_range=[-2, 2, 1]` is a flat hardcoded guess. A 5-term partial
sum of a square wave's Fourier series exhibits the Gibbs phenomenon — the
overshoot near each discontinuity approaches roughly 1.18× the wave's
amplitude and *increases slightly* (in absolute height, asymptotically) as
more terms are added, regardless of how many terms you sum.
**Why it matters:** The chosen `[-2, 2]` range happens to just barely contain
the overshoot for 5 terms in this run, but the range was never actually
computed from the harmonic count or the known overshoot bound — it was
guessed. Add a 6th or 7th harmonic (an easy edit a student might try) and
there is no guarantee the curve stays inside the visible y-range; it could
silently clip at the top/bottom of the frame with no warning.
**Fix:** Compute `y_range` from the known Gibbs bound, e.g.
`y_max = 1.3` (a safe constant above the ~1.18 overshoot ratio) rather than a
number that was eyeballed for this specific harmonic count.

## 5. Poor color contrast between adjacent harmonics
**Issue:** The harmonic colors used are `BLUE, GREEN, YELLOW, ORANGE, PURPLE`.
`YELLOW` (n=5) and `ORANGE` (n=7) sit very close together on the color wheel
and, against manim's default black background combined with the also-warm
`RED` partial-sum curve, become difficult to visually separate, especially
where curves cross near the same amplitude.
**Why it matters:** The whole point of color-coding harmonics is to let a
viewer track each one independently. Two similar warm hues sitting next to a
red curve undermine that, and the issue is worse for colorblind viewers
(red-green and red-orange confusion are common forms of color vision
deficiency).
**Fix:** Use a perceptually distinct, colorblind-friendly palette — e.g.
manim's `BLUE_D, GREEN_D, GOLD, MAROON, PURPLE` or an explicit Okabe-Ito-style
palette — and reserve a clearly unique hue (e.g. `WHITE` or a strong `PINK`)
exclusively for the partial-sum curve so it never competes visually with any
individual harmonic.

## Other minor notes
- The closure pattern `partial_sum(x, terms=running_terms[: i + 1])` correctly
  avoids Python's classic late-binding-in-a-loop bug by capturing `terms` as
  a default argument — this part of the generated code is actually solid and
  worth calling out as a positive, not just listing flaws.
- The harmonic frequency ratios themselves (`n = 1, 3, 5, 7, 9` with
  amplitude `(4/π)/n`) are mathematically correct for a square wave — this is
  not one of the bugs, despite frequency-ratio errors being a common failure
  mode in LLM-generated Fourier code in general.
