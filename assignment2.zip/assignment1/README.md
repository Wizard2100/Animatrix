# Assignment 1 — Gemini-Generated Manim Animations

This repo contains both parts of the assignment:

1. **Pythagorean Theorem** visual proof (`part1_pythagorean/`)
2. **Fourier Series** square-wave decomposition (`part2_fourier/`)

For each part you get: the script that calls the Gemini API, the Manim
scene code, a rendered video + screenshots, and a written critique of
5 specific shortcomings.

> **A note on how this was produced:** the `generate_pythagoras.py` /
> `generate_fourier.py` scripts here are complete, working calls to the
> Gemini API (`google-generativeai`) — point them at your own
> `GEMINI_API_KEY` and they will write a fresh `pythagoras.py` /
> `fourier_series.py` from the model's response. This particular sandbox
> had no network route to Google's API and no key configured, so the
> `pythagoras.py` and `fourier_series.py` files included here were written
> directly (using the exact same prompts as the scripts below) so that the
> rendering, screenshots, and critiques in this repo are real and already
> done for you. If your instructor requires the literal Gemini transcript,
> run the `generate_*.py` script yourself once — it will overwrite the
> scene file with the model's actual output, which you can then re-render
> and re-critique using the same process documented below.

## Repo structure
```
.
├── README.md
├── EXTENSION_IDEAS.md              # recommended future extensions (Task 2)
├── requirements.txt
├── .gitignore
├── part1_pythagorean/
│   ├── generate_pythagoras.py      # Gemini API call + prompt
│   ├── pythagoras.py                # the original LLM-generated scene (buggy)
│   ├── pythagoras_corrected.py      # FIXED scene — see "Corrected version" below
│   ├── pythagoras_render.mp4        # rendered animation (original, buggy)
│   ├── pythagoras_corrected_render.mp4 # rendered animation (fixed)
│   ├── pythagoras_frame_overlap.png # screenshot: square overlap issue (original)
│   ├── pythagoras_frame_final.png   # screenshot: final equation frame (original)
│   ├── corrected_frame_mid.png      # screenshot: squares correctly attached (fixed)
│   ├── corrected_frame_final.png    # screenshot: final equation frame (fixed)
│   └── critical_analysis.md         # 5 shortcomings + how each was fixed
└── part2_fourier/
    ├── generate_fourier.py         # Gemini API call + prompt
    ├── fourier_series.py            # the Manim scene
    ├── fourier_render.mp4           # rendered animation
    ├── fourier_frame_mid.png        # screenshot: mid-build harmonics
    ├── fourier_frame_final.png      # screenshot: final overlapping labels
    └── critical_analysis.md         # 5 shortcomings, write-up
```

## Corrected version of the Pythagorean Theorem scene

`part1_pythagorean/pythagoras_corrected.py` (scene name
`PythagoreanTheoremCorrected`) fixes all 5 issues found in the original
LLM-generated `pythagoras.py`:

```bash
cd part1_pythagorean
manim -ql pythagoras_corrected.py PythagoreanTheoremCorrected
```

Squares are now built directly from the triangle's edge vectors (so they're
geometrically attached to the correct side, for *any* triangle, not just
3-4-5), the whole diagram is scaled to guarantee it fits in frame, the
equation block no longer overlaps the diagram, and the broken `Transform`
call now actually animates. See `part1_pythagorean/critical_analysis.md`
for the full before/after breakdown.

## Suggested extensions
See `EXTENSION_IDEAS.md` for a prioritized list of additions worth
investing extra time in (automated layout/geometry tests, a multi-model
comparison harness, a self-correcting generate→render→critique→repair
loop, generalized parameters, CI rendering, narration, and a shared
"LLM + Manim pitfalls" reference).


## Setup

### 1. System dependencies (Manim needs these to render)
```bash
sudo apt-get update
sudo apt-get install -y ffmpeg pkg-config libcairo2-dev libpango1.0-dev python3-dev build-essential
```

### 2. Python dependencies
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Gemini API key
Get a key from [Google AI Studio](https://aistudio.google.com/app/apikey) and export it:
```bash
export GEMINI_API_KEY="your-api-key-here"
```

## Usage

### Part 1 — Pythagorean Theorem
```bash
cd part1_pythagorean

# (Optional) regenerate the scene from a live Gemini call:
python generate_pythagoras.py

# Render the scene (fast draft, 480p):
manim -ql pythagoras.py PythagoreanTheorem

# Or high quality, 1080p:
manim -qh pythagoras.py PythagoreanTheorem
```
The rendered file appears under `media/videos/pythagoras/<quality>/PythagoreanTheorem.mp4`.

### Part 2 — Fourier Series
```bash
cd part2_fourier

# (Optional) regenerate the scene from a live Gemini call:
python generate_fourier.py

# Render the scene:
manim -ql fourier_series.py FourierSeries
```
The rendered file appears under `media/videos/fourier_series/<quality>/FourierSeries.mp4`.

## Critical analyses
See `part1_pythagorean/critical_analysis.md` and
`part2_fourier/critical_analysis.md` — each documents 5 concrete issues
found by actually running and reviewing frame-by-frame the rendered output
(not just reading the code), with the specific fix for each.

## Publishing to GitHub

```bash
git init
git add .
git commit -m "Assignment 1: Gemini-generated Manim animations + critique"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

(Create the empty repo on GitHub first via the web UI or `gh repo create`.)
